const resources = [
  {
    id: 1,
    title: 'MDN Web Docs',
    category: 'HTML',
    description: '适合查阅HTML、CSS和JavaScript知识的权威文档。',
    url: 'https://developer.mozilla.org/zh-CN/',
  },
  {
    id: 2,
    title: 'CSS Tricks',
    category: 'CSS',
    description: '包含许多CSS布局、动画与实际开发技巧。',
    url: 'https://css-tricks.com/',
  },
  {
    id: 3,
    title: '现代JavaScript教程',
    category: 'JavaScript',
    description: '从基础语法逐步了解现代JavaScript。',
    url: 'https://zh.javascript.info/',
  },
  {
    id: 4,
    title: 'Can I use',
    category: '工具',
    description: '查询不同浏览器对Web特性的支持情况。',
    url: 'https://caniuse.com/',
  },
  {
    id: 5,
    title: 'Node.js学习指南',
    category: 'Node.js',
    description: '了解Node.js的基础概念与常见用法。',
    url: 'https://nodejs.org/zh-cn/learn',
  },
];

module.exports = resources;
